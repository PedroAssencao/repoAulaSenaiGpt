﻿using GptUsing.Services;

Client client = new Client();
Console.WriteLine(await client.GptRequest("", "Qual o melhor filme da barbie"));
Console.ReadKey();
