﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GptUsing.Services
{
    public class Client
    {
        private readonly HttpClient _httpClient = new HttpClient();
        private const string _baseurl = "https://api.openai.com/v1/chat";
        public async Task<string> GptRequest(string Authorization, string Request)
        {
            try
            {
                _httpClient.DefaultRequestHeaders.Add(nameof(Authorization), $"Bearer {Authorization}");

                var requestBody = new
                {
                    model = "gpt-4",
                    messages = new[]
                    {
                        new { role = "system", content = "Você é um Assistente" },
                        new { role = "user", content = Request }
                    },
                    max_tokens = 1000,
                    temperature = 0.7
                };

                var httpContent = new StringContent(JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync($"{_baseurl}/completions", httpContent);
                var jsonResponse = JsonConvert.DeserializeObject<dynamic>(await response.Content.ReadAsStringAsync());
                return jsonResponse.choices[0].message.content;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
